Examples:

    $ cd simpleproject/
    $ Change the llvm pass path in the makefile
    $ make CFLAG="-g -O0"
    $ ./test
    $ make clean
    $ make
    $ ./test

    You can see the difference between the two outputs.

CVEs:

    $ Dir CVE shows the real world programs we evaluated.

SPEC 2006:

    $ Dir SPEC stores experiment for spec 2006.
