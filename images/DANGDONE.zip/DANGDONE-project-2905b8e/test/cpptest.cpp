#include "iostream"

using namespace std;

int main()
{
    char *p = new char[10];
    delete p;
    return 1;
}
