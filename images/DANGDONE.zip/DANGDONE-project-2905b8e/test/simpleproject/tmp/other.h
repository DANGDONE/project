
typedef struct
{
    int num;
    char *buf;
    char **pbuf;
}ts;

void strFun(char * p);
void getAddr();
void testFun(char *p);
int strFun2(char p);
char *test5();
void structTest();
void structGTest();
void arrayTest();
void structPTest();
