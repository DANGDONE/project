make clean
make ast
/home/fff000/Documents/nodang/llvm/DangPointer/build/SDDang astList.txt config.txt ./
