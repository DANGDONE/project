
typedef struct
{
    int num;
    char *buf;
    char **pbuf;
}ts;

void structTest();
void structGTest();
void arrayTest();
void structPTest();
