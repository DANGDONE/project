cp ~/Documents/llvm/lib/Transforms/NoDang/*.cpp ./llvm/
cp ~/Documents/llvm/lib/Transforms/NoDang/*.h ./llvm/
cp ~/Documents/llvm/lib/Transforms/NoDang/Makefile ./llvm/

